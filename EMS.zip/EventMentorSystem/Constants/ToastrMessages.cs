﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EventMentorSystem.Constants
{
    public static class ToastrMessages
    {
        public static string InquirySuccessEndUser { get; } = "Your inquiry generated successfully. Our team will reach you very soon. Thank you!";
    }
}
